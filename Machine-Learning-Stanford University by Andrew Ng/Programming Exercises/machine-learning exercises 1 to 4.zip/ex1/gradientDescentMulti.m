function [theta, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters)
%GRADIENTDESCENTMULTI Performs gradient descent to learn theta
%   theta = GRADIENTDESCENTMULTI(x, y, theta, alpha, num_iters) updates theta by
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);
%size(theta')
%size(X')

% gumawa ako ng dummy na theta na paglalagyan ko ng mga theta values ko muna. 
dummy_theta=zeros(length(theta),1);


for iter = 1:num_iters

    % ====================== YOUR CODE HERE ======================
    % Instructions: Perform a single gradient step on the parameter vector
    %               theta. 
    %
    % Hint: While debugging, it can be useful to print out the values
    %       of the cost function (computeCostMulti) and gradient here.
    %
	
	% Parehas na computation ng gradientDescent.m, pero we must loop sa lahat ng features.
	for i=1:length(theta),

		dummy_theta(i,1)=theta(i,1)-((alpha/m))*sum(((X*theta)-y).*X(:,i));
		dummy_theta;
	end;
	
	%ibalik ulit sa original na lalagyan yung mga theta. parang sa gradientDescent.m
	theta=dummy_theta;
	
	








    % ============================================================

    % Save the cost J in every iteration    
    J_history(iter) = computeCostMulti(X, y, theta);


end
end
