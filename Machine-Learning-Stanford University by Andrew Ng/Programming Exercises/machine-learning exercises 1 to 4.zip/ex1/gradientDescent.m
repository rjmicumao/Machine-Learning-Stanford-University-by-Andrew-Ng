function [theta, J_history] = gradientDescent(X, y, theta, alpha, num_iters)
%GRADIENTDESCENT Performs gradient descent to learn theta
%   theta = GRADIENTDESCENT(X, y, theta, alpha, num_iters) updates theta by 
%   taking num_iters gradient steps with learning rate alpha

% Initialize some useful values
m = length(y); % number of training examples
J_history = zeros(num_iters, 1);

for iter = 1:num_iters

    % ====================== YOUR CODE HERE ======================
    % Instructions: Perform a single gradient step on the parameter vector
    %               theta. 
    %
    % Hint: While debugging, it can be useful to print out the values
    %       of the cost function (computeCost) and gradient here.
    
	% Follow mo lang yung formula ng gradient descent, then save mo sa bagong theta na gagamitin
	% ulit para sa next computation ng bagong theta. haha. magulo ba? 
	% No need na ilagay sa for loop. hehe. dadalawa lang naman ng mga theta mo.
	
	Bagong_theta1 = theta(1) - alpha * (1 / m) * sum(((X * theta) - y) .* X(:, 1));
    Bagong_theta2 = theta(2) - alpha * (1 / m) * sum(((X * theta) - y) .* X(:, 2));

	%e-change yung values ng theta.
    theta(1) = Bagong_theta1;
    theta(2) = Bagong_theta2;




    % ============================================================

    % Save the cost J in every iteration    
    J_history(iter) = computeCost(X, y, theta);

end

end
