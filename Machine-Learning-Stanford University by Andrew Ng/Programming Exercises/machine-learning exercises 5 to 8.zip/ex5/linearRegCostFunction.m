function [J, grad] = linearRegCostFunction(X, y, theta, lambda)
%LINEARREGCOSTFUNCTION Compute cost and gradient for regularized linear 
%regression with multiple variables
%   [J, grad] = LINEARREGCOSTFUNCTION(X, y, theta, lambda) computes the 
%   cost of using theta as the parameter for linear regression to fit the 
%   data points in X and y. Returns the cost in J and the gradient in grad

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost and gradient of regularized linear 
%               regression for a particular choice of theta.
%
%               You should set J to the cost and grad to the gradient.
%

% Kunin ung not regularized na cost function. follow lang ung formula. 

predicted_value = (X * theta);
cost = (1 / (2 * m)) * sum((predicted_value - y) .^ 2);

% Kunin ung regularization_term pero ignore muna natin ung theta sub 1

regularization_term = (lambda / (2 * m)) * sum(theta(2:end) .^ 2);

% kunin ung buong cost. sum lang yan. madali lang
J = cost + regularization_term;


% Calculate linear regression gradient.
% initialize ko muna ung theta(1) ko sa zero which is hindi dapat. 
theta(1) = 0;

% just follow the formula. 
grad = (1 / m) .* (X' * (predicted_value - y)) + ((lambda / m) .* theta);











% =========================================================================

grad = grad(:);

end
